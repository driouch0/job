$(function () {

	'use strict';

	/* Profile Page */

	var html = "<div class='row g-gs' id='str'><div class='col-md-12'><h4 class='nk-block-title fw-normal' style='text-align: center;'>Détails sur l'éducation</h4></div><div class='col-md-12'><div class='form-group'><label class='form-label'>Nom de l'établissement</label><div class='form-control-wrap'><input type='text' data-msg='Obligatoire' class='form-control required' name='school[]' required></div></div></div><div class='col-md-6'><div class='form-group'><label class='form-label'>Niveau</label><div class='form-control-wrap'><input type='text' data-msg='Obligatoire' class='form-control required' name='niveau[]' required></div></div></div><div class='col-md-6'><div class='form-group'><label class='form-label'>Filière</label><div class='form-control-wrap'><input type='text' data-msg='Obligatoire' class='form-control required' name='filiere[]' required></div></div></div><div class='col-md-6'><div class='form-group'><label class='form-label'>Mention</label><div class='form-control-wrap'><input type='text' data-msg='Obligatoire' class='form-control required' name='mention[]' required></div></div></div><div class='col-md-6'><div class='form-group'><label class='form-label'>Année d'Obtention</label><div class='form-control-wrap'><div class='form-icon form-icon-left'><em class='icon ni ni-calendar'></em></div><input type='text' name='year[]' class='form-control' placeholder='1990 - 2022'></div></div></div><div class='col-md-12'><div class='form-group'><label class='form-label' for='cf-default-textarea'>Note Courte</label><div class='form-control-wrap'><textarea type='text' class='form-control form-control-sm' id='cf-default-textarea' placeholder='Écrivez une courte note... (optionnelle)' style='height: 122px;' name='note[]'></textarea></div></div></div><div class='col-md-12'><div class='form-group'><a id='remove' class='btn btn-dim btn-outline-danger'>Supprimer</a></div></div></div>";
	
	var max = 10;
	var x = 1;


	$('#addBTN').click(function () {
		if (x <= max) {
			$('#addMore').append(html);
			x++;
		}
	});

	$('#education').on('click', '#remove', function () {
		$(this).closest('#str').remove();
		x--;
	});

















});
