<?php


	/*
	** Get All Function v2.0
	** Function To Get All Rows From Any Database Table
	*/

	function getAllFrom($field, $table, $where = NULL, $or = NULL, $and = NULL, $orderBY, $ordering = 'ASC', $limit = NULL) {

		global $con;

		
		$where = ($where == NULL) ? NULL : 'WHERE ' . $where;

		$and = ($and == NULL) ? NULL : 'AND ' . $and;

		$or = ($or == NULL) ? NULL : 'OR ' . $or;

		$limit = ($limit == NULL) ? NULL : 'LIMIT ' . $limit;

			$getAll = $con->prepare("SELECT $field FROM $table $where $or $and ORDER BY $orderBY $ordering $limit");

			$getAll->execute();

			$all = $getAll->fetchALL();

			return $all;

	}

	/*
	** INSERT INTO Function v1.0
	** Function To INSERT row INTO Database Table
	*/


	/*
	** Get One Function v2.1
	** Function To Get One Row From Any Database Table
	*/

	function getOne($field, $table, $where = NULL, $and = NULL, $or = NULL) {

		global $con;

		$where = ($where == NULL) ? NULL : 'WHERE ' . $where;

		$and = ($and == NULL) ? NULL : 'AND ' . $and;

		$or = ($or == NULL) ? NULL : 'OR ' . $or;


			$getOne = $con->prepare("SELECT $field FROM $table $where $and $or");

			$getOne->execute();

			$one = $getOne->fetch();

			return $one;

	}

	/*
	** Get INNER JOIN Function v3.0
	** Function To Get INNER JOIN From Any Database Table
	*/

	function InnerJoin($field, $table, $inner_join, $on, $inner_join2 = NULL, $on2 = NULL, $where = NULL, $or = NULL, $and = NULL, $orderBY, $ordering = 'ASC', $limit = NULL) {

		global $con;

		$inner_join2 	= ($inner_join2 == NULL) ? NULL : 'INNER JOIN ' . $inner_join2;

		$Inner_Join_2 	= ($on2 == NULL) ? NULL : $inner_join2 . ' ON ' . $on2;

		$where 			= ($where == NULL) ? NULL : 'WHERE ' . $where;

		$or 			= ($or == NULL) ? NULL : 'OR ' . $or;

		$and 			= ($and == NULL) ? NULL : 'AND ' . $and;

		$limit 			= ($limit == NULL) ? NULL : 'LIMIT ' . $limit;

			$Inner_Join = $con->prepare("SELECT $field FROM $table INNER JOIN $inner_join ON $on $Inner_Join_2 $where $or $and ORDER BY $orderBY $ordering $limit");

			$Inner_Join->execute();

			$Join = $Inner_Join->fetchALL();

			return $Join;

	}

	/*
	** Update Function v1.0
	** Function To Update From Any Database Table
	*/

	function UpdateFrom($table, $value, $where, $and = NULL) {

		global $con;

		$and = ($and == NULL) ? NULL : 'AND ' . $and;

			$Update = $con->prepare("UPDATE $table SET $value WHERE $where $and");

			$Update->execute();

			$Success = $Update->rowCount();

			return $Success;

	}

	/*
	** Check If User Is Not Activated Function v1.0
	** Function To Check The RegStatus Of The User
	*/

	function checkUserStatus($user) {

			global $con;

			$stmtx = $con->prepare("SELECT Username, RegStatus FROM users WHERE Username = ? AND Regstatus = 0");

			$stmtx->execute(array($user));

			$status = $stmtx->rowCount();

			return $status;
	}

	/*
	** Check Items Function v1.0
	** Function To Check Items In Database [ Function Accept Parameters ]
	*/

	function checkItem($field, $table, $where, $or = NULL, $and = NULL) {

		global $con;

			$or = ($or == NULL) ? NULL : 'OR ' . $or;

			$and = ($and == NULL) ? NULL : 'AND ' . $and;

		$stmt2 = $con->prepare("SELECT $field FROM $table WHERE $where $or $and");

		$stmt2->execute();

		$count = $stmt2->rowCount();

		return $count;
	}

	/*
	** Title Function v1.0
	** Title Function Thet Echo The Page Title In Case The Page
	** The Variable $pageTitle And Eche Defult Title For Other Pages
	*/

	function getTitle() {

		global $pageTitle;

		if (isset($pageTitle)) {

			return $pageTitle;

		} else {

			return "Defult";

		}

	}

	/*
	** Home Redirect Function v2.0
	** This Function Accept Parameters
	** $errorMsg = Echo The Message [ Error | Success | Warning ]
	** $url = The Link You Want To Redirect To
	** $seconds = Seconds Before Redirecting
	*/

	function redirectHome($theMsg, $url = null, $seconds = 3) {

		if ($url === null) {

			$url = 'index.php';

			$pageName = 'HomePage';
			
		} else {

			if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] !== '') {

				$url = $_SERVER['HTTP_REFERER'];

				$pageName = 'Previous Page';

			} else {

				$url = 'index.php';

				$pageName = 'HomePage';

			}

		}

		echo $theMsg;

		echo "<div class='alert alert-info'>You Well Be Redirected To $pageName After $seconds Seconds. </div>";

		header("refresh:$seconds;url=$url");

		exit();

	}

	/*
	** Count Number Function v1.0
	** Function To Count Number Of Items Rows
	** $item = The Items To Count
	** $table = The Table To Choose From
	*/

	function countItems($field, $table, $where = NULL) {

		global $con;

		$where = ($where == NULL) ? NULL : 'WHERE ' . $where;

		$stmt3 = $con->prepare("SELECT COUNT($field) FROM $table $where");

		$stmt3->execute();

		return $stmt3->fetchColumn();
	}

