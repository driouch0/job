<?php

	function lang($phrase) {

		static $lang = array(

			// Navbar Links

			'Categories'	=> 'Categories',
			'Home_Admin'	=> 'Admin Area',
			'Items' 		=> 'Items',
			'Members'	 	=> 'Members',
			'Comments'		=> 'Comments',
			'statistics'	=> 'statistics',
			'Logs' 		 	=> 'Logs',
			''	=> '',
			''	=> '',
			''	=> '',
			''	=> '',
			''	=> ''

		);
		return $lang[$phrase];
	}