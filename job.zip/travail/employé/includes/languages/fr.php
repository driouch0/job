<?php

	function lang($phrase) {

		static $lang = array(
			'welcome' 	=> 'Beinvenu',
			'admin' 	=> 'Directeur'
		);
		return $lang[$phrase];
	}