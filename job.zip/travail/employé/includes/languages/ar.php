<?php

	function lang($phrase) {

		static $lang = array(
			'welcome' 	=> 'ahlan',
			'admin' 	=> 'modir'
		);
		return $lang[$phrase];
	}