<?php

/*
=========================================================
================== Manage 'Profile' Page ==================
=========================================================
*/


ob_start("ob_gzhandler"); // Output Buffering Start
session_start();

if (isset($_SESSION['users_ID'])):

	$pageTitle = 'Profile';

	include 'init.php';

    $nices   = array();


    if ($_SERVER['REQUEST_METHOD'] == 'POST'):
        
        $form = filter_var($_POST['form'],    FILTER_SANITIZE_NUMBER_INT); # form ID

        if ($form == 1) {
        
            $first_name   = filter_var($_POST['first-name'], 	    FILTER_SANITIZE_STRING);
            $last_name    = filter_var($_POST['last-name'], 	    FILTER_SANITIZE_STRING);
            $sex          = filter_var($_POST['sex'], 	            FILTER_SANITIZE_NUMBER_INT);
            $date_n       = filter_var($_POST['date-n'], 	        FILTER_SANITIZE_STRING);
            $email        = filter_var($_POST['email'], 	        FILTER_SANITIZE_EMAIL);
            $phone        = "+212" . filter_var($_POST['phone'],    FILTER_SANITIZE_NUMBER_INT);
            $ville        = filter_var($_POST['ville'], 	        FILTER_SANITIZE_NUMBER_INT);
            $cat          = filter_var($_POST['cat'], 	            FILTER_SANITIZE_NUMBER_INT);
            $info         = filter_var($_POST['info'], 	            FILTER_SANITIZE_STRING);
            $tags         = filter_var($_POST['tags'], 	            FILTER_SANITIZE_STRING);


            $stmt = $con->prepare("UPDATE users SET first_name = ?, 
                    last_name = ?, 
                    sex = ?, 
                    birthday = ?, 
                    phone = ?, 
                    city = ?, 
                    category = ?, 
                    about = ?,
                    compétences = ?
                WHERE users_ID = ?");

            $stmt->execute(array( $first_name, 
                    $last_name, 
                    $sex, 
                    $date_n, 
                    $phone, 
                    $ville, 
                    $cat, 
                    $info,
                    $tags, 
                $_SESSION['users_ID'] ));


            $UpdateProfile = $stmt->rowCount();


            if ($UpdateProfile == 0) {
            echo "<script> alert('Noooo... 😥') </script>";
            } else {
            echo "<script> alert('Yeess... 😄') </script>";
            }

        } elseif ($form == 3) {


            if ( isset($_POST['school']) ) {

                $f_school   = array();
                $f_niveau   = array();
                $f_filiere  = array();
                $f_mention  = array();
                $f_e_date   = array();
                $f_note     = array();

                echo '<div class="nk-content ">
                <div class="container-fluid">
                    <div class="nk-content-inner">
                        <div class="nk-content-body">';

                for ($i=0; $i < count($_POST['school']); $i++) { 

                    $errors = array();

                    if (isset($_POST['school'][$i]) && $_POST['school'][$i] !== '') {
                        $school     = filter_var($_POST['school'][$i], 	    FILTER_SANITIZE_STRING);
                    } else {
                        $errors[] = "éducation " . ($i + 1) . " : Nom de l'établissement ne peut pas être vide";
                    }

                    if (isset($_POST['niveau'][$i]) && $_POST['niveau'][$i] !== '') {
                        $niveau     = filter_var($_POST['niveau'][$i], 	    FILTER_SANITIZE_STRING);
                    } else {
                        $errors[] = "éducation " . ($i + 1) . " : Niveau ne peut pas être vide";
                    }
        
                    if (isset($_POST['filiere'][$i]) && $_POST['filiere'][$i] !== '') {
                        $filiere    = filter_var($_POST['filiere'][$i], 	    FILTER_SANITIZE_STRING);
                    } else {
                        $errors[] = "éducation " . ($i + 1) . " : Filiere ne peut pas être vide";
                    }
        
                    if (isset($_POST['mention'][$i]) && $_POST['mention'][$i] !== '') {
                        $mention    = filter_var($_POST['mention'][$i], 	    FILTER_SANITIZE_STRING);
                    } else {
                        $errors[] = "éducation " . ($i + 1) . " : Mention ne peut pas être vide";
                    }

                    if (empty($errors)) {

                            # School
                        if (strlen($school) <= 3) {
                            $errors[] = "éducation " . ($i + 1) . " : Nom de l'établissement est trop court";
                        } elseif (strlen($school) > 25) {
                            $errors[] = "éducation " . ($i + 1) . " : Nom de l'établissement est trop long";
                        }

                            # niveau
                        if (strlen($niveau) <= 3) {
                            $errors[] = "éducation " . ($i + 1) . " : Niveau est trop court";
                        } elseif (strlen($niveau) > 25) {
                            $errors[] = "éducation " . ($i + 1) . " : Niveau est trop long";
                        }

                            # filiere
                        if (strlen($filiere) <= 3) {
                            $errors[] = "éducation " . ($i + 1) . " : Filière est trop court";
                        } elseif (strlen($filiere) > 25) {
                            $errors[] = "éducation " . ($i + 1) . " : Filière est trop long";
                        }

                            # mention
                        if (strlen($mention) <= 3) {
                            $errors[] = "éducation " . ($i + 1) . " : Mention est trop court";
                        } elseif (strlen($mention) > 15) {
                            $errors[] = "éducation " . ($i + 1) . " : Mention est trop long";
                        }

                            # End date

                        if (isset($_POST['year'][$i]) && $_POST['year'][$i] !== '') {

                            if (filter_var($_POST['year'][$i], FILTER_VALIDATE_INT)) {

                                if (strlen($_POST['year'][$i]) == 4) {

                                    $e_date = $_POST['year'][$i];
                                    
                                } else {

                                    $errors[] = "éducation " . ($i + 1) . " : Date d'Obtention est incorrecte";

                                }

                            } else {

                                $errors[] = "éducation " . ($i + 1) . " : Date d'Obtention est incorrecte";

                            }

                        } else {

                            $e_date = "---";

                        }

                            # note
                        if ((isset($_POST['note'][$i]) && $_POST['note'][$i] !== '')) {

                            $note = filter_var($_POST['note'][$i], FILTER_SANITIZE_STRING);

                        } else {
                            $note = "";
                        }

                        if (empty($errors)) {

                            $f_school[]   = $school;
                            $f_niveau[]   = $niveau;
                            $f_filiere[]  = $filiere;
                            $f_mention[]  = $mention;
                            $f_e_date[]   = $e_date;
                            $f_note[]     = $note;

                        }

                    }

                }

                echo '</div></div></div></div>';

            }

        }
    
    endif;


?>


<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block-head nk-block-head-lg wide-sm">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><a class="back-to" href="#"><em class="icon ni ni-arrow-left"></em><span>Components</span></a></div>
                            <h2 class="nk-block-title fw-normal">Modifier Mon Profil</h2>
                        </div>
                    </div><!-- .nk-block-head -->




<?php

if (isset($errors) && empty($errors)) {

    if (isset($f_school) && !empty($f_school)) { 

        $INSERTéducation = 0;

        foreach ($f_school as $key => $value) {
    
            $stmt2 = $con->prepare("INSERT INTO 
                                        education(etablissement, niveau, filiere, mention, obtention, note)
                                    VALUES 
                                        (:zetablissement, :zniveau, :zfiliere, :zmention, :zobtention, :znote) ");
        
            $stmt2->execute(array( 
        
                'zetablissement' 	=> $f_school[$key],
                'zniveau' 	        => $f_niveau[$key],
                'zfiliere' 	        => $f_filiere[$key],
                'zmention' 	        => $f_mention[$key],
                'zobtention' 	    => $f_e_date[$key],
                'znote' 	        => $f_note[$key]
        
            ));
        
        
            $INSERTéducation = ( $INSERTéducation + $stmt2->rowCount() );

        }

        if ($INSERTéducation == 0) {
            echo "<script> alert('Noooo... 😥') </script>";
        } else {
            echo "<script> alert('Yeess... " . $INSERTéducation . " éducation ajoutées avec succès 😄') </script>";
        }
    
    }

} elseif (isset($errors) && !empty($errors)) {
    
    foreach ($errors as $error) {
        echo '<h4>' . $error . '</h4><br>';
    }

}

?>

                    
                    <div class="nk-block nk-block-lg">
                        <div class="card">
                            <div class="card-inner">
                                <ul class="nav nav-tabs nav-tabs-s2">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#tabItem9"><em class="icon ni ni-user"></em><span>Renseignements Personnels</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#tabItem10"><em class="icon ni ni-img-fill"></em><span>Mes Images</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#tabItem11"><em class="icon ni ni-book-read"></em><span>Éducation</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#tabItem12">nav</a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tabItem9">
                                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-validate is-alter" novalidate="novalidate" method="POST">
                                            <div class="row g-gs">

                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                        <label class="form-label">Prénom</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="first-name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="form-label">Nom</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="last-name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label class="form-label">Sexe / Genre</label>
                                                        <div class="form-control-wrap">
                                                            <ul class="custom-control-group">
                                                                <li>
                                                                    <div class="custom-control custom-radio custom-control-pro no-control">
                                                                        <input type="radio" data-msg="Obligatoire" class="custom-control-input" name="sex" id="sex-male" value="1" required="">
                                                                        <label class="custom-control-label" for="sex-male">Homme</label>
                                                                    </div>
                                                                </li>
                                                                <li>
                                                                    <div class="custom-control custom-radio custom-control-pro no-control">
                                                                        <input type="radio" data-msg="Obligatoire" class="custom-control-input" name="sex" id="sex-female" value="2" required="">
                                                                        <label class="custom-control-label" for="sex-female">Femme</label>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Adresse E-mail</label>
                                                        <div class="form-control-wrap">
                                                            <input type="email" data-msg="Obligatoire" data-msg-email="E-mail non valide" class="form-control required email" id="fw-email-address" name="email" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Numéro de Téléphone</label>
                                                        <div class="input-group">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text">+212</span>
                                                            </div>
                                                            <input type="number" data-msg="Obligatoire" class="form-control required" name="phone" placeholder="6xxxxxxxx" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Ville</label>
                                                        <div class="form-control-wrap">
                                                            <select class="form-select required invalid" data-search="on" data-msg="Obligatoire" name="ville" required="">
                                                                <option value="1">Marrakech</option>
                                                                <option value="2">Rabat</option>
                                                                <option value="3">Casablanca</option>
                                                                <option value="4">Agadir</option>
                                                                <option value="5">El Souira</option>
                                                                <option value="6">El Jadida</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Date de naissance</label>
                                                        <div class="form-control-wrap">
                                                        <div class="form-icon form-icon-left">
                                                                <em class="icon ni ni-calendar"></em>
                                                            </div>
                                                            <input type="text" name="date-n" class="form-control date-picker" placeholder="Format de date ( jj-mm-aaaa )" data-date-format="dd-mm-yyyy" data-msg="Obligatoire" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">travail Catégorie</label>
                                                        <div class="form-control-wrap">
                                                            <select class="form-select required invalid" data-search="on" data-msg="Obligatoire" name="cat" required="">
                                                                    <option value="1">Markting</option>
                                                                    <option value="2">Ai</option>
                                                                    <option value="3">Comptabilité</option>
                                                                    <option value="4">RH</option>
                                                                    <option value="5">Develepment</option>
                                                                    <option value="6">Biologique</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">compétences</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="tags" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label" for="cf-default-textarea">Informations sur Vous</label>
                                                        <div class="form-control-wrap">
                                                            <textarea type="text" data-msg="Obligatoire" class="form-control form-control-sm" id="cf-default-textarea" placeholder="Écrivez quelques Informations sur Vous..." style="height: 122px;" name="info" required></textarea>
                                                        </div>
                                                    </div>
                                                </div><!-- .col -->
                                                <input type="hidden" name="form" value="1"><!-- form ID -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-lg btn-primary" style="float: right;">Enregistrer les Informations</button>
                                                    </div>
                                                </div><!-- .btn -->

                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane" id="tabItem10">
                                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-validate is-alter" novalidate="novalidate" method="POST" enctype="multipart/form-data">
                                            <div class="row g-gs">
                                                <div class="col-md-4">
                                                    <label class="form-label">Photo de Profil</label>
                                                    <div class="upload-zone">
                                                        <div class="dz-message" data-dz-message>
                                                            <span class="dz-message-text">Drag and drop file</span>
                                                            <span class="dz-message-or">or</span>
                                                            <input type="file" multiple="multiple" name="p-img" class="dz-hidden-input" tabindex="-1" style="visibility: hidden; position: absolute; top: 0px; left: 0px; height: 0px; width: 0px;">
                                                            <button class="btn btn-primary">SELECT</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <label class="form-label">Photo de Couverture</label>
                                                    <div class="upload-zone">
                                                        <div class="dz-message" data-dz-message>
                                                            <span class="dz-message-text">Drag and drop file</span>
                                                            <span class="dz-message-or">or</span>
                                                            <button class="btn btn-primary">SELECT</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="form" value="2"><!-- form ID -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-lg btn-primary" style="float: right;">Enregistrer les Images</button>
                                                    </div>
                                                </div><!-- .btn -->
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane" id="tabItem11">
                                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-validate is-alter" id="education" novalidate="novalidate" method="POST">
                                            <div class="row g-gs">
                                                <div class="col-md-12">
                                                    <h4 class="nk-block-title fw-normal" style="text-align: center;">Détails sur l'éducation</h4>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label">Nom de l'établissement</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="school[]" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Niveau</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="niveau[]" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Filière</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="filiere[]" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Mention</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" data-msg="Obligatoire" class="form-control required" name="mention[]" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">End Date</label>
                                                        <div class="form-control-wrap">
                                                        <div class="form-icon form-icon-left">
                                                                <em class="icon ni ni-calendar"></em>
                                                            </div>
                                                            <input type="text" name="year[]" class="form-control" placeholder="Format de date ( jj-mm-aaaa )">
                                                            <code>Si vous ne l'avez pas encore, laissez-le vide</code>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label" for="cf-default-textarea">Note Courte</label>
                                                        <div class="form-control-wrap">
                                                            <textarea type="text" class="form-control form-control-sm" id="cf-default-textarea" placeholder="Écrivez une courte note... (optionnelle)" style="height: 122px;" name="note[]"></textarea>
                                                        </div>
                                                    </div>
                                                </div><!-- .col -->

                                                <div class="col-md-12" id="addMore"></div><!-- Add More content -->

                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <a id="addBTN" class="btn btn-outline-dark"style="width: 100%; justify-content: center;">Ajouter un de Plus</a>
                                                    </div>
                                                </div><!-- Add More button -->

                                                <input type="hidden" name="form" value="3"><!-- form ID -->

                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-lg btn-primary" style="float: right;">Enregistrer les Informations</button>
                                                    </div>
                                                </div><!-- .btn:submit -->
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane" id="tabItem12">
                                        <p>contnet4</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- .nk-block -->
                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>


<?php

	include $tpl . 'footer.php';

else:

	header('Location: ../login.php');
	exit();

endif;

ob_end_flush();