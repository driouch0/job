<?php

	// Error Reporting

	ini_set('display_errors', 'on');
	error_reporting(E_ALL);

	include 'connect.php';

	$sessionUser = '';
	if (isset($_SESSION['users_ID'])) {
		$sessionUser = $_SESSION['users_ID'];
	}

	//routes
	$css	 = 'layout/css/';
	$vondor	 = 'layout/vendors/';
	$chartjs = 'layout/vendors/chartjs/';
	$scrol	 = 'layout/vendors/perfect-scrollbar/';
	$imgs	 = 'images/';
	$js		 = 'layout/js/';
	$func	 = 'includes/functions/';
	$tpl 	 = 'includes/templetes/';

	// Include The Important Files

	include $func . 'functions.php';
	include $tpl . 'header.php';

	include $tpl . 'navbar.php';