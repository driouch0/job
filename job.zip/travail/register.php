<?php

    ob_start("ob_gzhandler"); // Output Buffering Start
    session_start();

    if (isset($_SESSION['users_ID'])) {

        header('Location: index.php'); //Redirect To Home Page
        exit();

    }

    $pageTitle = 'Register';

    $NoHomeNav = '';

    $noFooter = '';

    include 'init.php';

        //Check If User Coming From HTTP Post Request

        if ($_SERVER['REQUEST_METHOD'] == 'POST'):

                $pepper       = "c1i(sv*-FdxM_D/d14@@963m00.jOlvx##pecFw";

                $name1        = $_POST['1st-name'];
                $name2        = $_POST['last-name'];
                $email        = $_POST['email'];
                $pass         = $_POST['password'];
                $hash         = md5($pass) . $pepper;
                $hashpass     = sha1($pass);

                    //Check If User Exist In Database

                $stmt_check = $con->prepare("SELECT * FROM users WHERE email = ?");

                $stmt_check->execute(array($email));

                $count = $stmt_check->rowCount();
                
                // if Count >  0 This Mean The Database Contain Record About This Username

                if ($count == 0):

                    if (isset($name1)) {

                        if (empty($_POST['1st-name'])) {
    
                            $formErrors[] = 'Sorry First Name Can\'t Be <strong>Empty</strong>';
    
                        } else {
    
                            $filterdUser = filter_var($name1, FILTER_SANITIZE_STRING);
    
                            if (strlen($filterdUser) < 3) {
    
                            $formErrors[] = 'Sorry First Name Must Be Larger Then <strong>3 Characters</strong>';
                                
                            } elseif (strlen($filterdUser) > 15) {
    
                                $formErrors[] = 'Sorry First Name Can\'t Be More Then <strong>15 Characters</strong>';
    
                            }
    
                        }
    
                    }

                    if (isset($name2)) {

                        if (empty($_POST['last-name'])) {
    
                            $formErrors[] = 'Sorry Last Name Can\'t Be <strong>Empty</strong>';
    
                        } else {
    
                            $filterdUser = filter_var($name2, FILTER_SANITIZE_STRING);
    
                            if (strlen($filterdUser) < 2) {
    
                            $formErrors[] = 'Sorry Last Name Must Be Larger Then <strong>2 Characters</strong>';
                                
                            } elseif (strlen($filterdUser) > 15) {
    
                                $formErrors[] = 'Sorry Last Name Can\'t Be More Then <strong>15 Characters</strong>';
    
                            }
    
                        }
    
                    }

                    if (isset($email)) {

                        if (empty($email)) {
    
                            $formErrors[] = 'Sorry Email Can\'t Be <strong>Empty</strong>';
    
                        } else {
    
                            $filterdEmail = filter_var($email, FILTER_SANITIZE_EMAIL);
    
                            if (filter_var($filterdEmail, FILTER_VALIDATE_EMAIL) != true) {
                                
                                $formErrors[] = 'Sorry This Email Is Not <strong>Valid</strong>';
    
                            }
    
                        }
    
                    }

                    if (empty($_POST['password'])) {

						$formErrors[] = 'Sorry Password Can\'t Be <strong>Empty</strong>';

					}

                    if (isset($_POST['accept'])) {

                        $accept = $_POST['accept'];

                        if (empty($accept)) {
    
                            $formErrors[] = 'Sorry You Have To Accept Our <strong>Privacy Policy & Terms.</strong> ';
    
                        } else {
    
                            $accept = filter_var($accept, FILTER_SANITIZE_STRING);

                            if ($accept == "on") {

                                $accept = 1;

                            } else {

                                $formErrors[] = 'Sorry You Have To Accept Our <strong>Privacy Policy & Terms.</strong> ';
                            
                            }
    
                        }
    
                    } else {

                        $formErrors[] = 'Sorry You Have To Accept Our <strong>Privacy Policy & Terms.</strong> ';

                    }

                    if (empty($formErrors)) {

                        // Insert User Info In Database

                        $stmt = $con->prepare("INSERT INTO 
													users(first_name, last_name, email, pwd, Date)
												VALUES 
													(:zfirst_name, :zlast_name, :zemail, :zpassword, now()) ");
						$stmt->execute(array(

							'zfirst_name' 	=> $name1,
							'zlast_name' 	=> $name2,
							'zemail' 	    => $email,
							'zpassword' 	=> $hashpass

						));
    
                        // Echo Success Message
    
                        $successMsg = '<h1>Congrats You Are Now <strong>Registerd User</strong></h1>';

                        if ($stmt) {





















                            echo $successMsg;
                            header('Location: login.php'); //Redirect To Home Page
                            exit();
                        } else {
                            echo "<h1>Error Error Error Error Error</h1>";
                        }
                        
                    } else {
                        foreach ($formErrors as $error) {
                            echo "<h1>" . $error . "</h1>";
                        }
                    }

                else:
                
                    echo "<h1>Sorry This E-mail Already Exist</h1>";
                
                endif;
      endif;

?>

<div class="nk-app-root">
    <div class="nk-main ">
        <div class="nk-wrap nk-wrap-nosidebar">
            <div class="nk-content ">
                <div class="nk-split nk-split-page nk-split-md">
                    <div class="nk-split-content nk-block-area nk-block-area-column nk-auth-container bg-white w-lg-45">
                        <div class="absolute-top-right d-lg-none p-3 p-sm-5">
                            <a href="#" class="toggle btn btn-white btn-icon btn-light" data-target="athPromo"><em class="icon ni ni-info"></em></a>
                        </div>
                        <div class="nk-block nk-block-middle nk-auth-body">
                            <div class="brand-logo pb-5">
                                <a href="html/index.html" class="logo-link">
                                    <img class="logo-light logo-img logo-img-lg" src="./images/logo.png" srcset="./images/logo2x.png 2x" alt="logo">
                                    <img class="logo-dark logo-img logo-img-lg" src="./images/logo-dark.png" srcset="./images/logo-dark2x.png 2x" alt="logo-dark">
                                </a>
                            </div>
                            <div class="nk-block-head">
                                <div class="nk-block-head-content">
                                    <h5 class="nk-block-title">Register</h5>
                                    <div class="nk-block-des">
                                        <p>Create New Dashlite Account</p>
                                    </div>
                                </div>
                            </div>
                            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                                <div class="form-group row">
                                    <div class="col-md-6">
                                        <label class="form-label" for="name">First Name</label>
                                        <input type="text" name="1st-name" class="form-control form-control-lg" id="name" required="required" placeholder="Enter your name">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" for="name">Last Name</label>
                                        <input type="text" name="last-name" class="form-control form-control-lg" id="name" required="required" placeholder="Enter your name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="email">Email</label>
                                    <input type="email" name="email" class="form-control form-control-lg" id="email" required="required" placeholder="Enter your email address or username">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="password">Password</label>
                                    <div class="form-control-wrap">
                                        <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch" data-target="password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                                        </a>
                                        <input type="password" name="password" class="form-control form-control-lg" required="required" id="password" placeholder="Enter your passcode">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-control-xs custom-checkbox">
                                        <input type="checkbox" name="accept" class="custom-control-input" id="checkbox" required="required">
                                        <label class="custom-control-label" for="checkbox">I agree to Dashlite <a tabindex="-1" href="#">Privacy Policy</a> &amp; <a tabindex="-1" href="#"> Terms.</a></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-lg btn-primary btn-block">Register</button>
                                </div>
                            </form>
                            <div class="form-note-s2 pt-4"> Already have an account ? <a href="login.php"><strong>Sign in instead</strong></a>
                            </div>
                            <div class="text-center pt-4 pb-3">
                                <h6 class="overline-title overline-title-sap"><span>OR</span></h6>
                            </div>
                            <ul class="nav justify-center gx-8">
                                <li class="nav-item"><a class="nav-link" href="#">Facebook</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Google</a></li>
                            </ul>
                        </div>
                        <div class="nk-block nk-auth-footer">
                            <div class="nk-block-between">
                                <ul class="nav nav-sm">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Terms & Condition</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Privacy Policy</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Help</a>
                                    </li>
                                    <li class="nav-item dropup">
                                        <a class="dropdown-toggle dropdown-indicator has-indicator nav-link" data-toggle="dropdown" data-offset="0,10"><small>English</small></a>
                                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
                                            <ul class="language-list">
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/english.png" alt="" class="language-flag">
                                                        <span class="language-name">English</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/spanish.png" alt="" class="language-flag">
                                                        <span class="language-name">Español</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/french.png" alt="" class="language-flag">
                                                        <span class="language-name">Français</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/turkey.png" alt="" class="language-flag">
                                                        <span class="language-name">Türkçe</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="mt-3">
                                <p>&copy; 2021 School Of ABC. All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                    <div class="nk-split-content nk-split-stretch bg-abstract"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include $tpl . 'footer.php';

    ob_end_flush();
?>