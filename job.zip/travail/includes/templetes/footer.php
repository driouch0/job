
	<?php if (!isset($noFooter)) { ?>

		<div class="nk-footer">
			<div class="container-fluid">
				<div class="nk-footer-wrap">
					<div class="nk-footer-copyright"> &copy; 2021 travail. This Website Created with <span style="color: #0969c3;">❤</span> by Driouch
					</div>
					<div class="nk-footer-links">
						<ul class="nav nav-sm">
							<li class="nav-item"><a class="nav-link" href="#">Terms</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Privacy</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Help</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>

	<?php } ?>



		<!-- Bundles of Included plugins -->
		<script src="<?php echo $js; ?>bundle.js"></script>

		<script src="<?php echo $js; ?>scripts.js"></script>
		

		<script src="<?php echo $js; ?>jquery.min.js"></script>
		<!-- Example code for toastr -->
		<script src="<?php echo $js; ?>example-toastr.js"></script>
		<!-- Example code for sweetalert2 -->
		<script src="<?php echo $js; ?>example-sweetalert.js"></script>
		<script src="<?php echo $js; ?>sweetalert.min.js"></script>
		<script src="<?php echo $js; ?>vanilla-tilt.js"></script>


		<!--=== jQuery Modernizr Min Js ===-->
		<script src="<?php echo $js; ?>modernizr.js"></script>
		<!--=== jQuery Migration Min Js ===-->
		<script src="<?php echo $js; ?>jquery-migrate.js"></script>
		<!--=== jQuery Popper Min Js ===-->
		<script src="<?php echo $js; ?>popper.min.js"></script>
		<!--=== jQuery Bootstrap Min Js ===-->
		<script src="<?php echo $js; ?>bootstrap.min.js"></script>
		<!--=== jQuery Swiper Min Js ===-->
		<script src="<?php echo $js; ?>swiper.min.js"></script>
		<!--=== jQuery Fancybox Min Js ===-->
		<script src="<?php echo $js; ?>fancybox.min.js"></script>
		<!--=== jQuery Aos Min Js ===-->
		<script src="<?php echo $js; ?>aos.min.js"></script>
		<!--=== jQuery Counterup Min Js ===-->
		<script src="<?php echo $js; ?>counterup.js"></script>
		<!--=== jQuery Waypoint Js ===-->
		<script src="<?php echo $js; ?>waypoint.js"></script>

		<!--=== jQuery Custom Js ===-->
		<script src="<?php echo $js; ?>custom.js"></script>
		

    	<script src="<?php echo $js; ?>style.js"></script>
	</body>
</html>
