<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Driouch">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="travail Ma.">

    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo $imgs; ?>favicon.png">







    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>bootstrap.min.css" rel="stylesheet" />
    <!-- Icofont Icon CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>icofont.css" rel="stylesheet" />
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>swiper.min.css" rel="stylesheet" />
    <!-- Fancybox Min CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>fancybox.min.css" rel="stylesheet" />
    <!-- Aos Min CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>aos.min.css" rel="stylesheet" />
    <!-- Not Main Style CSS -->
    <link rel="stylesheet" href="<?php echo $css; ?>nStyle.css" rel="stylesheet" />







    <!-- Page Title  -->
    <title><?php echo getTitle(); ?> | MA travail</title>





    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo $css; ?>dashlite.min.css">

    <!-- Skin style -->
    <link id="skin-default" rel="stylesheet" href="<?php echo $css; ?>theme-blue.css">

   <!-- OtherStyles  -->
   <link rel="stylesheet" href="<?php echo $css; ?>style.css">

</head>

<body>