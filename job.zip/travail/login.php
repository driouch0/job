<?php

    ob_start("ob_gzhandler"); // Output Buffering Start
    session_start();

    if (isset($_SESSION['users_ID'])) {

        header('Location: index.php'); //Redirect To Home Page
        exit();

    }

    $pageTitle = 'Login';

    $NoHomeNav = '';

    $noFooter = '';

    include 'init.php';
 
        //Check If User Coming From HTTP Post Request

        if ($_SERVER['REQUEST_METHOD'] == 'POST'):

            $pepper     = "c1i(sv*-FdxM_D/d14@@963m00.jOlvx##pecFw";

            $email      = $_POST['email'];
            $pass       = $_POST['password'];
            $hash       = md5($pass) . $pepper;
			$hashpass   = sha1($pass);

                //Check If User Exist In Database

                $stmt = $con->prepare("SELECT * FROM users WHERE email = ? AND pwd = ?");

                $stmt->execute(array($email, $hashpass));
                $row = $stmt->fetch();
                $count = $stmt->rowCount();
            
            // if Count == 1 This Mean The Database Contain Record About This Username

            if ($stmt->rowCount() == 1):

                if ($row['type'] == 0) {

                    $_SESSION['Admin'] = $row['first_name'] . $gerowt['last_name']; // Register Session Name

                } elseif ($row['type'] == 1) {

                    $_SESSION['Stager'] = $row['first_name'] . $row['last_name']; // Register Session Name

                } else {

                    $_SESSION['Entereprise'] = $row['first_name'] . $row['last_name']; // Register Session Name

                }

                $_SESSION['users_ID'] = $row['users_ID']; // Register Session ID
                $active = UpdateFrom('users', 'active = 1', "users_ID = " . $_SESSION['users_ID']); // Active Chat
                
                header('Location: index.php'); //Redirect To Home Page
                exit();
                
            else:
                
                echo "<h1>Sorry</h1>";
                

            endif;

        endif;

?>

<div class="nk-app-root">
    <div class="nk-main ">
        <div class="nk-wrap nk-wrap-nosidebar">
            <div class="nk-content ">
                <div class="nk-split nk-split-page nk-split-md">
                    <div class="nk-split-content nk-block-area nk-block-area-column nk-auth-container bg-white">
                        <div class="absolute-top-right d-lg-none p-3 p-sm-5">
                            <a href="#" class="toggle btn-white btn btn-icon btn-light" data-target="athPromo"><em class="icon ni ni-info"></em></a>
                        </div>
                        <div class="nk-block nk-block-middle nk-auth-body">
                            <div class="brand-logo pb-5">
                                <a href="html/index.html" class="logo-link">
                                    <img class="logo-light logo-img logo-img-lg" src="./images/logo.png" srcset="./images/logo2x.png 2x" alt="logo">
                                    <img class="logo-dark logo-img logo-img-lg" src="./images/logo-dark.png" srcset="./images/logo-dark2x.png 2x" alt="logo-dark">
                                </a>
                            </div>
                            <div class="nk-block-head">
                                <div class="nk-block-head-content">
                                    <h5 class="nk-block-title">Sign-In</h5>
                                    <div class="nk-block-des">
                                        <p>Access the DashLite panel using your email and passcode.</p>
                                    </div>
                                </div>
                            </div>
                            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                                <div class="form-group">
                                    <div class="form-label-group">
                                        <label class="form-label" for="default-01">Email</label>
                                        <a class="link link-primary link-sm" tabindex="-1" href="#">Need Help?</a>
                                    </div>
                                    <input type="email" name="email" class="form-control form-control-lg" id="default-01" required="required" placeholder="Enter your email address">
                                </div>
                                <div class="form-group">
                                    <div class="form-label-group">
                                        <label class="form-label" for="password">Passcode</label>
                                        <a class="link link-primary link-sm" tabindex="-1" href="reset-pass.php">Forgot Code?</a>
                                    </div>
                                    <div class="form-control-wrap">
                                        <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch" data-target="password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                                        </a>
                                        <input type="password" name="password" class="form-control form-control-lg" id="password" required="required" placeholder="Enter your passcode">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-lg btn-primary btn-block">Sign in</button>
                                </div>
                            </form>
                            <div class="form-note-s2 pt-4"> New on our platform? <a href="register.php">Create an account</a>
                            </div>
                            <div class="text-center pt-4 pb-3">
                                <h6 class="overline-title overline-title-sap"><span>OR</span></h6>
                            </div>
                            <ul class="nav justify-center gx-4">
                                <li class="nav-item"><a class="nav-link" href="#">Facebook</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Google</a></li>
                            </ul>
                            <div class="text-center mt-5">
                                <span class="fw-500">I don't have an account? <a href="#">Try 15 days free</a></span>
                            </div>
                        </div>
                        <div class="nk-block nk-auth-footer">
                            <div class="nk-block-between">
                                <ul class="nav nav-sm">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Terms & Condition</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Privacy Policy</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Help</a>
                                    </li>
                                    <li class="nav-item dropup">
                                        <a class="dropdown-toggle dropdown-indicator has-indicator nav-link" data-toggle="dropdown" data-offset="0,10"><small>English</small></a>
                                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
                                            <ul class="language-list">
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/english.png" alt="" class="language-flag">
                                                        <span class="language-name">English</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/spanish.png" alt="" class="language-flag">
                                                        <span class="language-name">Español</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/french.png" alt="" class="language-flag">
                                                        <span class="language-name">Français</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="language-item">
                                                        <img src="./images/flags/turkey.png" alt="" class="language-flag">
                                                        <span class="language-name">Türkçe</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="mt-3">
                                <p>&copy; 2021 School Of ABC. All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                    <div class="nk-split-content nk-split-stretch bg-abstract"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include $tpl . 'footer.php';

    ob_end_flush();
?>