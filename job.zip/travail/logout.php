<?php

	ob_start("ob_gzhandler"); // Output Buffering Start

		include 'init.php';

		session_start();

		if (isset($_SESSION['users_ID'])):

			UpdateFrom('users', 'active = 0', "users_ID = " . $_SESSION['users_ID']);

		endif;

		session_unset();

		session_destroy();

		header('Location: login.php');

		exit();

	ob_end_flush();

?>