<?php

/*
=========================================================
================== Manage 'Home' Page ==================
=========================================================
*/


ob_start("ob_gzhandler"); // Output Buffering Start
session_start();

//if (isset($_SESSION['users_ID'])):

	$pageTitle = 'Home';

	include 'init.php';

?>


<div class="home-page">

	<section class="main-index" style="background-color: #e6f0f9;" data-aos="fade-down">
		<div class="hero-caption">
			<div class="caption-container container">
				<div class="row cap-center">
					<div class="col-12 col-xl-6 col-xxl-5">

						<h1>Trouvez le Parfait<br><span style="color: #0969c3;">travail</span> pour vous</h1>

						<div class="subtitle">Trouvez votre opportunité de carrière à travers <strong>12,800</strong> formations</div>

						<div class="search-box">
							<form class="row align-items-center form-control-wrap" action="index.php" method="$_GET">
								<div class="col-12 col-sm padding">
									<div class="mb-3 mb-sm-0">
										<input type="text" name="keyword" class="form-control" placeholder="Titre ou Mot-Clé du travail">
									</div>
								</div>
								<div class="col-12 col-sm pxp-has-left-border padding">
									<div class="mb-3 mb-sm-0">
										<select name="category" class="form-select" data-ui="sl" data-search="on">
											<option value="1">Option 1</option>
											<option value="2">Option 2</option>
											<option value="3">Option 3</option>
										</select>
									</div>
								</div>
								<div class="col-12 col-sm-auto padding-btn">
								<button type="submit" class="btn btn-round btn-icon btn-lg btn-primary"><em class="icon ni ni-search"></em></button>
								</div>
							</form>
						</div>

						<div class="searches-container">
							<div class="searches-label">Popular Searches</div>
							<div class="searches">
								<div class="searches-items">
									<a href="#">Work from home</a>
									<a href="#">Part-time</a>
									<a href="#">Administration</a>
									<a href="#">Finance</a>
									<a href="#">Retail</a>
									<a href="#">IT</a>
									<a href="#">Engineering</a>
									<a href="#">Sales</a>
									<a href="#">Manufacturing</a>
								</div>
							</div>
						</div>

					</div>
					<div class="d-none d-xl-block col-xl-5">
						<div class="img-cards-container">
							<div class="img-main-card" style="background-image: url(/travail/images/home-img.jpg);"></div>
							<div class="img-card-blue"></div>
							<div class="img-card-light"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="pxp-hero-right-bg-card pxp-has-animation pxp-animate"></div>
	</section>

	<section class="main-index2" data-aos="fade-down">
		<div class="index2">
			
			<h2 class="index2-section-h2 text-center">Rechercher par Catégorie</h2>
			
			<p class="index2-text-light text-center">Recherchez votre Opportunité de Carrière avec nos Catégories</p>
			
			<div class="row mt-4 mt-md-5">
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
				<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 cat-card">
					<a href="#" class="index2-categories-card-1">
						<div class="index2-categories-card-1-icon-container">
							<div class="index2-categories-card-1-icon">
								<em class="icon ni ni-terminal"></em>
							</div>
						</div>
						<div class="index2-categories-card-1-title">Business Development</div>
						<div class="index2-categories-card-1-subtitle">139 open positions</div>
					</a>
				</div>
			</div>

			<div class="cat-btn mt-4 mt-md-5">
			<a href="#" class="btn btn-round btn-lg btn-primary"><span>toutes catégories</span><em class="icon ni ni-arrow-right"></em></a>
			</div>

		</div>
	</section>

	<section class="main-index3" data-aos="fade-down">

		<section class="recent-job-area">
			<div class="container" data-aos="fade-down">
				<div class="row">
					<div class="col-12">
						<div class="travail-card text-center">
							<h2 class="pxp-section-h2 text-center">Offres de travail en Vedette</h2>
							<p class="pxp-text-light text-center">Trouvez votre opportunité de carrière à travers 12,800 formations</p>
						</div>
					</div>
				</div>
				<div class="row">

					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type">Full-time</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type" data-text-color="#ff7e00" style="color: rgb(255, 126, 0);">Part-time</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type" data-text-color="#03a84e" style="color: rgb(0, 84, 255);">Remote</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type">Full-time</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type">Full-time</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					<div class="col-md-6 col-lg-4">
						<!--== Start Recent Job Item ==-->
						<div class="recent-job-item">
							<div class="company-info">
								<div class="logo">
									<a href="#"><img src="assets/img/companies/1.jpg" width="75" height="75" alt="Image-HasTech"></a>
								</div>
								<div class="content">
									<h4 class="name"><a href="#">Darkento Ltd.</a></h4>
									<p class="address">New York, USA</p>
								</div>
							</div>
							<div class="main-content">
								<h3 class="title"><a href="#">Front-end Developer</a></h3>
								<h5 class="work-type">Full-time</h5>
								<p class="desc">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
							</div>
							<div class="recent-job-info">
								<div class="salary">
									<h4>$5000</h4>
									<p>/monthly</p>
								</div>
								<a href="#" class="btn btn-dim btn-outline-primary">Apply Now</a>
							</div>
						</div>
						<!--== End Recent Job Item ==-->
					</div>
					
				</div>
			</div>
		</section>

	</section>

	<section class="main-index4 work-process-area">
		<div class="container" data-aos="fade-down">
			<div class="row">
				<div class="col-12">
					<div class="section-title text-center" >
						<h2 class="title">Comment ça marche?</h2>
						<div class="desc">
							<p>De nombreux packages de publication assistée par ordinateur et éditeurs de pages Web</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="working-process-content-wrap">
						<div class="working-col">
							<!--== Start Work Process ==-->
							<div class="working-process-item">
								<div class="icon-box">
									<div class="inner">
										<em class="icon ni ni-user-alt-fill"></em>
									</div>
								</div>
								<div class="content">
									<h4 class="title">Créer un compte</h4>
								</div>
								<div class="shape-arrow-icon">
									<em class="icon ni ni-arrow-long-right"></em>
								</div>
							</div>
							<!--== End Work Process ==-->
						</div>
						<div class="working-col">
							<!--== Start Work Process ==-->
							<div class="working-process-item">
								<div class="icon-box">
									<div class="inner">
										<em class="icon ni ni-file-docs"></em>
									</div>
								</div>
								<div class="content">
									<h4 class="title">Remplissez vos informations + CV</h4>
								</div>
								<div class="shape-arrow-icon">
									<em class="icon ni ni-arrow-long-right"></em>
								</div>
							</div>
							<!--== End Work Process ==-->
						</div>
						<div class="working-col">
							<!--== Start Work Process ==-->
							<div class="working-process-item">
								<div class="icon-box">
									<div class="inner">
										<em class="icon ni ni-search"></em>
									</div>
								</div>
								<div class="content">
									<h4 class="title">Trouvez votre travail</h4>
								</div>
								<div class="shape-arrow-icon">
									<em class="icon ni ni-arrow-long-right"></em>
								</div>
							</div>
							<!--== End Work Process ==-->
						</div>
						<div class="working-col">
							<!--== Start Work Process ==-->
							<div class="working-process-item">
								<div class="icon-box">
									<div class="inner">
										<em class="icon ni ni-send"></em>
									</div>
								</div>
								<div class="content">
									<h4 class="title">Appliquer</h4>
								</div>
							</div>
							<!--== End Work Process ==-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="main-index5 team-area">
		<div class="container" data-aos="fade-down">
			<div class="row">
				<div class="col-12">
					<div class="section-title text-center" >
						<h2 class="title">Best Candidate</h2>
						<div class="desc">
							<p>Many desktop publishing packages and web page editors</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
				<div class="col-sm-6 col-lg-4 col-xl-3">
					<!--== Start Team Item ==-->
					<div class="team-item">
						<div class="thumb">
							<a href="#">
								<img src="assets/img/team/1.jpg" width="160" height="160" alt="Image-HasTech">
							</a>
						</div>
						<div class="content">
							<h4 class="title"><a href="#">Lauran Benitez</a></h4>
							<h5 class="sub-title">Web Designer</h5>
							<div class="rating-box">
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
								<em class="icon ni ni-star-fill"></em>
							</div>
							<p class="desc">CSS3, HTML5, Javascript Bootstrap, Jquery</p>
							<a href="#" class="btn btn-round btn-primary">
								<em class="icon ni ni-user-c"></em>
								<span>Voir le profil</span> 
							</a>
						</div>
					</div>
					<!--== End Team Item ==-->
				</div>
			</div>
		</div>
	</section>

	<section class="main-index6 testimonial-area">
		<div class="container" data-aos="fade-down">
			<div class="row">
				<div class="col-12">
					<div class="section-title text-center" >
						<h3 class="title">Our Happy Clients</h3>
						<div class="desc">
							<p>Many desktop publishing packages and web page editors</p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="swiper testi-slider-container">
						<div class="swiper-wrapper">
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
							<div class="swiper-slide">
								<!--== Start Testimonial Item ==-->
								<div class="testimonial-item">
									<div class="testi-inner-content">
										<div class="testi-author">
											<div class="testi-thumb">
												<img src="assets/img/testimonial/1.jpg" width="75" height="75" alt="Image-HasTech">
											</div>
											<div class="testi-info">
												<h4 class="name">Roselia Hamets</h4>
												<span class="designation">Hiring Manager</span>
											</div>
										</div>
										<div class="testi-content">
											<p class="desc">It is a long established fact that reader will distracted the readable content page looking at its layout point using that has more-or-less normal distribution of letters opposed using content making.</p>
											<div class="row">
												<div class="col-6 rating-box">
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
													<em class="icon ni ni-star-fill"></em>
												</div>
												<div class="col-6">
													<p>15 test</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--== End Testimonial Item ==-->
							</div>
						</div>

						<!--== Add Swiper Pagination ==-->
						<div class="swiper-pagination"></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="main-index7" data-aos="fade-down">
		<h2 class="text-center">Stay Up to Date</h2>
		<p class="text-center">Subscribe to our newsletter to receive our weekly feed.</p>
		<div class="row mt-4 mt-md-5 justify-content-center">
			<div class="col-md-9 col-lg-7 col-xl-6 col-xxl-5">
				<div class="subscribe-1-image">
					<img src="images/subscribe.png" alt="Stay Up to Date">
				</div>
				<form>
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Enter your email...">
						<button class="btn btn-primary" type="button">Subscribe<span class="fa fa-angle-right"></span></button>
					</div>
				</form>
			</div>
		</div>
	</section>

</div>


<?php

	include $tpl . 'footer.php';

//else:
//
//	header('Location: login.php');
//	exit();
//
//endif;

ob_end_flush();