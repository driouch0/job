$(function () {

	'use strict';

/* NavBar Fix */

	$(window).scroll(function () {
		if ($(window).scrollTop()) {
			$('.nk-header-fluid').addClass('block');
		} else {
			$('.nk-header-fluid').removeClass('block');
		}
	});

/* Movement Animation in Home Page */

	const card 			= document.querySelector('.img-cards-container');
	const section1	 	= document.querySelector('.main-index');
	const main_card 	= document.querySelector('.img-main-card');
	const card_blue 	= document.querySelector('.img-card-blue');
	const card_light 	= document.querySelector('.img-card-light');

	section1.addEventListener("mousemove", (e) => {
		let xAxis = (window.innerWidth / 2 - e.pageX) / 50;
		let yAxis = (window.innerHeight / 2 - e.pageY) / 50;
		card.style.transform = `translateX(${xAxis}px) translateY(${yAxis}px)`;
	  });
	
		//Animate In
	section1.addEventListener("mouseenter", (e) => {
		card.style.transition = "none";
	});

		//Animate Out
	section1.addEventListener("mouseleave", (e) => {
		card.style.transition = "all 0.5s ease";
		card.style.transform = `translateY(0px) translateX(0px)`;
	});

/* Movement Vanilla Tilt Animation in Home Page - travail card */

	VanillaTilt.init(document.querySelectorAll(".recent-job-item"), {
		max: 25,
		speed: 400
	});

/* Movement Toastr Message */

	$('.test').on("click", function (e) {
		e.preventDefault();
		toastr.clear();
		NioApp.Toast('This is dark version note of toast message.', 'success');
	});






























});
